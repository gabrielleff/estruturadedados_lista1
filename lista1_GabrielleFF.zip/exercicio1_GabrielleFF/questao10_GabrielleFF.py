# 10. Crie um programa que simule o jogo "Pedra, Papel e Tesoura" entre o usuário e o computador. O programa deve solicitar a escolha do usuário e, em seguida, escolher aleatoriamente a escolha do computador e determinar o vencedor.

import random

opcoes = ["Pedra", "Papel", "Tesoura"]

usuario = input("Escolha: Pedra, Papel ou Tesoura: ")
computador = random.choice(opcoes)

print("O computador escolheu:", computador)

if usuario == computador:
    print("Empate!")
elif (
    (usuario == "Pedra" and computador == "Tesoura")
    or (usuario == "Papel" and computador == "Pedra")
    or (usuario == "Tesoura" and computador == "Papel")
):
    print("Você venceu!")
else:
    print("O computador venceu!")
