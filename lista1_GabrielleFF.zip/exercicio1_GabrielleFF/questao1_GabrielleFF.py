# Faça um programa que calcule a média de três números inseridos pelo usuário.

num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))
num3 = float(input("Digite o terceiro número: "))

media = (num1 + num2 + num3) / 3

print("A média dos números é:", media)