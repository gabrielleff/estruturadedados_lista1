# 5. Faça um programa que leia uma lista de números e retorne a média dos números pares.

numeros = [int(x) for x in input("Digite a lista de números separados por espaço: ").split()]

numeros_pares = [num for num in numeros if num % 2 == 0]

if len(numeros_pares) > 0:
    media_pares = sum(numeros_pares) / len(numeros_pares)
    print("Média dos números pares:", media_pares)
else:
    print("Não há números pares na lista.")