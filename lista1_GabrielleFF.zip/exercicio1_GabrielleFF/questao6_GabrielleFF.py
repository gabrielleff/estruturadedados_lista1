# 6. Escreva um programa que peça um número inteiro positivo ao usuário e calcule o fatorial desse número.

numero = int(input("Digite um número inteiro positivo: "))

if numero < 0:
    print("Digite um número positivo.")
else:
    fatorial = 1
    for i in range(1, numero + 1):
        fatorial *= i
    print("O fatorial de", numero, "é", fatorial)
