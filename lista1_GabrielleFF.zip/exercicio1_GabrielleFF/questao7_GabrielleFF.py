# 7. Crie um programa que imprima a sequência de Fibonacci até um valor inserido pelo usuário.

n = int(input("Digite um valor para a sequência de Fibonacci: "))
a, b = 0, 1

while a <= n:
    print(a, end=" ")
    a, b = b, a + b