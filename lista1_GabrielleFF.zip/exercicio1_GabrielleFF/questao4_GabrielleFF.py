# 4. Crie um programa que leia uma lista de números e exiba o maior e o menor valor da lista.

numeros = [int(x) for x in input("Digite a lista de números separados por espaço: ").split()]

maior = max(numeros)
menor = min(numeros)

print("Maior valor:", maior)
print("Menor valor:", menor)